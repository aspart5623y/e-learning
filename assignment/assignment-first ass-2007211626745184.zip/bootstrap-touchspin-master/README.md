# Bootstrap TouchSpin [![Build Status](https://travis-ci.org/istvan-ujjmeszaros/bootstrap-touchspin.svg?branch=master)](https://travis-ci.org/istvan-ujjmeszaros/bootstrap-touchspin)

##### Bootstrap TouchSpin is a mobile and touch friendly input spinner component for Bootstrap 3 & 4.

- [Website](http://www.virtuosoft.eu/code/bootstrap-touchspin/)

Please report issues and feel free to make feature suggestions as well.

## License

Apache License, Version 2.0
